var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-email/route.js")
R.c("server/chunks/[externals]__cadba808._.js")
R.c("server/chunks/[root-of-the-server]__dc2249be._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_send-email_route_actions_1ffacf48.js")
R.m(43206)
module.exports=R.m(43206).exports
