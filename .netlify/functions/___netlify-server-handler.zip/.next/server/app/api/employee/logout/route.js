var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/logout/route.js")
R.c("server/chunks/[root-of-the-server]__84758516._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_employee_logout_route_actions_b951a846.js")
R.m(71261)
module.exports=R.m(71261).exports
