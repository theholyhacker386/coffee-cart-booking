var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/signup/route.js")
R.c("server/chunks/[root-of-the-server]__92a2b844._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3577e4f1._.js")
R.c("server/chunks/_next-internal_server_app_api_employee_signup_route_actions_df16c441.js")
R.m(42177)
module.exports=R.m(42177).exports
