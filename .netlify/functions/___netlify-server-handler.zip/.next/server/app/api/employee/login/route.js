var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/login/route.js")
R.c("server/chunks/[root-of-the-server]__7f4b5349._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_3577e4f1._.js")
R.c("server/chunks/_next-internal_server_app_api_employee_login_route_actions_cf2c7380.js")
R.m(42880)
module.exports=R.m(42880).exports
