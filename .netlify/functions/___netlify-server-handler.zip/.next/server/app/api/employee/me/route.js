var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/me/route.js")
R.c("server/chunks/[root-of-the-server]__3e1cc9f1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_next-internal_server_app_api_employee_me_route_actions_f197dfb1.js")
R.m(75474)
module.exports=R.m(75474).exports
