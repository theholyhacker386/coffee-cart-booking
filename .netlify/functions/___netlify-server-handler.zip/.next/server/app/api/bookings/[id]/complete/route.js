var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/complete/route.js")
R.c("server/chunks/[root-of-the-server]__fd89d6f4._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_3577e4f1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__efafb54b._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_complete_route_actions_8e7edb53.js")
R.m(68111)
module.exports=R.m(68111).exports
