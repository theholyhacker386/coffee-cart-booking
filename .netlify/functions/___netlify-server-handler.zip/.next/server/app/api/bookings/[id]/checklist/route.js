var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/checklist/route.js")
R.c("server/chunks/[root-of-the-server]__31a22ec9._.js")
R.c("server/chunks/node_modules_next_f5199d09._.js")
R.c("server/chunks/_3577e4f1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_checklist_route_actions_a9d95067.js")
R.m(18858)
module.exports=R.m(18858).exports
