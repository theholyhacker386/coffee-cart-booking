module.exports=[82383,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_send-email_route_actions_1ffacf48.js.map