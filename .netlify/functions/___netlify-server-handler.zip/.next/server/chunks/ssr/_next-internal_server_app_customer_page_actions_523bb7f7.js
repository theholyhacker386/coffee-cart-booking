module.exports=[51336,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customer_page_actions_523bb7f7.js.map