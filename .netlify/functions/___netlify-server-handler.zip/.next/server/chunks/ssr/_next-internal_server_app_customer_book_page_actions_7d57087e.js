module.exports=[88291,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customer_book_page_actions_7d57087e.js.map