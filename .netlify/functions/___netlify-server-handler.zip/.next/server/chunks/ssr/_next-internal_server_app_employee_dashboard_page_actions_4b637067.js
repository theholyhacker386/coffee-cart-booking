module.exports=[96099,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_employee_dashboard_page_actions_4b637067.js.map