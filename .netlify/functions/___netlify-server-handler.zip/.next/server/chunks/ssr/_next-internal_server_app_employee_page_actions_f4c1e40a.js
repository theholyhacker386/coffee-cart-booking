module.exports=[62572,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_employee_page_actions_f4c1e40a.js.map