module.exports=[29267,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("div",{className:"min-h-screen bg-gray-950",children:a})}a.s(["default",()=>c,"metadata",0,{title:"Employee Portal | The Porch Coffee Bar",description:"Employee portal for The Porch Coffee Bar"}])}];

//# sourceMappingURL=app_employee_layout_tsx_64214fb4._.js.map